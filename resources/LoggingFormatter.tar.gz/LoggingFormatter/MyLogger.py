# -*- coding: utf-8 -*-
import json
import logging
import logging.handlers
import os


# 创建一个自定义的日志过滤器，用于过滤掉一些不需要的日志信息
class InfoFilter(logging.Filter):
    def __init__(self, filter_rules_path="./FilterRules.json"):
        logging.Filter.__init__(self)
        self.filter_rules_path = filter_rules_path
        self.filter_rules = self.load_filter_rules()
        self.Error = 0

    def load_filter_rules(self):
        dirname = os.path.dirname(self.filter_rules_path)
        if dirname:  # 避免当前目录时创建空字符串目录
            try:
                os.makedirs(dirname)
            except Exception:
                pass
        if not os.path.exists(self.filter_rules_path):
            with open(self.filter_rules_path, "w") as file:
                json.dump({"levelname": [], "filter_names": [], "key_words": []}, file)

        with open(self.filter_rules_path, "r") as file:
            self.Error = 0
            return json.load(file)

    def filter(self, record):
        if not self.filter_rules:
            return True

        filter_levelnames = self.filter_rules.get(
            "levelname", ("DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL")
        )
        if record.levelname in filter_levelnames:
            return False

        filter_names = self.filter_rules.get("filter_names", ())
        if record.name in filter_names:
            return False

        key_words = set(self.filter_rules.get("key_words", ()))  # 使用集合提高查找效率
        for KeyWord in key_words:
            if KeyWord in record.msg:
                return False

        return True

    def rules_stat(self):
        return self.Error, self.filter_rules


def create_logger(name, owner=None):
    logger = logging.getLogger(name)
    logger.setLevel(logging.DEBUG)
    if owner is None:
        log_file = "./log/console.log"
    else:
        log_file = "./log/" + name + ".log"
    file_handler = logging.handlers.RotatingFileHandler(
        log_file, maxBytes=1024 * 1024 * 5, backupCount=3, encoding="utf-8"
    )
    file_handler.setLevel(logging.DEBUG)
    formatter = logging.Formatter(
        "%(name)s - %(asctime)s - %(levelname)s - %(message)s"
    )
    formatter.datefmt = "%Y-%m-%d %H:%M:%S"
    file_handler.setFormatter(formatter)
    logger.addHandler(file_handler)
    logger.addFilter(InfoFilter())

    # console_hander = logging.StreamHandler()
    # console_hander.setLevel(logging.DEBUG)
    # console_hander.setFormatter(formatter)
    # logger.addHandler(console_hander)
    return logger
