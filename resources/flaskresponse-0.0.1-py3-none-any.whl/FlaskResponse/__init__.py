from FlaskResponse.ResposeTypes import AutoOptionsReturn, jks_message

Singleline = "singleline"
Mutiline = "multiline"
Output = "output"

__all__ = ["jks_message", "AutoOptionsReturn"]
__version__ = "1.0.0"
