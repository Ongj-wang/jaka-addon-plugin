import functools
import json
import re

import flask


class customerProgram_data:
    def __init__(self, msg_data):
        self.is_variable = False
        self.value = 0
        self.change_data(msg_data)

    def change_data(self, msg):
        if "dict" not in str(__class__):
            msg = json.loads(msg)
            self.is_variable = bool(msg["type"])
            self.value = msg["value"]


class Response:
    def __init__(self):
        """根据请求类型建立对象"""
        if flask.request.method == "GET":
            self.params = flask.request.args
            self.method = "get"

        elif flask.request.method == "OPTIONS":
            self.method = "options"

        elif flask.request.method == "POST":
            self.params = flask.request.get_json()
            self.method = "post"
        # 获取路由名称
        self.route = flask.request.url_rule.rule.split("/")[-1]

    def key_exist(self, key):
        """判断get请求中，是否包含这个键值对"""
        exist = True
        try:
            json.loads(self.params.get(key))["value"]
        except Exception:
            exist = False
        return exist

    def get(self, key=-1):
        """获取指定的键值对，若传入-1，则返回所有键值对"""
        data = None
        if self.method == "get":
            if key != -1:
                if self.key_exist(key):
                    data = customerProgram_data(self.params.get(key))
                else:
                    raise ValueError("no this key")
            else:
                data_list = self.params.items()
                data = {}
                data["is_variable"] = {}
                customer_pattern = (
                    r'^{"value"\s*:\s*[^,}]+\s*,\s*"type"\s*:\s*[^,}]+\s*}$'
                )
                # 遍历所有数据
                for item in data_list:
                    if re.match(customer_pattern, item[1]):
                        data_group = json.loads(item[1])
                        key_name = item[0]
                        data[key_name] = data_group["value"]
                        data["is_variable"][key_name] = bool(data_group["type"])
                    else:
                        data[item[0]] = item[1]
        elif self.method == "post":
            if key == -1:
                return self.params
            else:
                data = self.params[key]
        return data

    def getint(self, key):
        if self.method == "get":
            data = json.loads(self.params.get(key).encode("utf-8"))["value"]
            if "." in data:
                return float(data)
            else:
                return int(data)
        elif self.method == "post":
            return self.get(key)

    def data_type(self, key):
        data = json.loads(self.params.get(key).encode("utf-8"))["type"]
        return data

    def post_message(self, message={}):
        res = flask.make_response()
        if self.method in ["post", "get"]:
            res = flask.make_response(message)
        res.headers["Access-Control-Allow-Origin"] = "*"
        res.headers["Access-Control-Allow-Methods"] = "*"
        res.headers["Access-Control-Allow-Headers"] = "*"
        res.headers["Access-Control-Allow-Credentials"] = "true"
        return res


def jks_message(
    blocktype="",
    jks_str=[],
    jks_return="",
    error_code=0,
    errormsg="",
):
    _reuslt = {"error_code": error_code, "type": blocktype}
    _reuslt["jksstr"] = {
        "jks": [jks.strip("\n") for jks in jks_str],
        "jks_return": jks_return,
    }
    _reuslt["lines"] = [jks.count("\n") + 1 if jks else 0 for jks in jks_str]

    return _reuslt


MULTIRES = {}


def AutoOptionsReturn(func):
    """
    装饰器: 针对OPTIONS请求，返回一个空响应
    """

    @functools.wraps(func)
    def wrapper():
        http_data = Response()
        if http_data.method == "options":
            return http_data.post_message()
        elif http_data.method == "get" and http_data.route in MULTIRES:
            jksItem = MULTIRES[http_data.route]
            getTimes = jksItem["gettimes"]
            ret = {
                "begin_jksstr": jksItem["jks"].pop(0) if getTimes == 0 else "",
                "begin_lines": jksItem["lines"].pop(0) if getTimes == 0 else 0,
                "end_jksstr": jksItem["jks"].pop(0),
                "end_lines": jksItem["lines"].pop(0),
            }
            MULTIRES[http_data.route]["gettimes"] += 1
            if not jksItem["jks"]:
                del MULTIRES[http_data.route]
            return http_data.post_message(ret)
        try:
            data = http_data.get()
            ret = func(data)
            if ret.get("type") == "multiline" and http_data.method == "get":
                MULTIRES[http_data.route] = {
                    "gettimes": 0,
                    "jks": ret["jksstr"]["jks"],
                    "lines": ret["lines"],
                }
                ret = jks_message("singleline", [""])
            return http_data.post_message(ret)
        except Exception as e:
            return http_data.post_message({"code": -1, "message": str(e)})

    return wrapper
