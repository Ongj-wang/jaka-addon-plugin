# -*- coding: utf-8 -*-
import collections
import configparser
import json
import os
import re
import threading


class _MyConfigparser(configparser.ConfigParser):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._lock = threading.RLock()
        self._encoding = "utf-8"
        # self._filePath = None

    def optionxform(self, optionstr):
        """
        重写optionxform方法，保持原始大小写而不是转换为小写

        Args:
            optionstr (str): 配置项名称

        Returns:
            str: 保持原始大小写的配置项名称
        """
        return optionstr

    def get(self, section, option, *args, **kwargs):
        """
        重写get方法，使用锁保证线程安全

        Args:
            section (str): 配置项所属的section
            option (str): 配置项名称
            *args: 可变参数
            **kwargs: 关键字参数

        Returns:
            str: 配置项的值
        """
        with self._lock:
            return super().get(section, option, *args, **kwargs)

    def getint(self, section, option, *args, **kwargs):
        """
        重写getint方法，使用锁保证线程安全

        Args:
            section (str): 配置项所属的section
            option (str): 配置项名称
            *args: 可变参数
            **kwargs: 关键字参数

        Returns:
            int: 配置项的值
        """
        with self._lock:
            return super().getint(section, option, *args, **kwargs)

    def getfloat(self, section, option, *args, **kwargs):
        """
        重写getfloat方法，使用锁保证线程安全

        Args:
            section (str): 配置项所属的section
            option (str): 配置项名称
            *args: 可变参数
            **kwargs: 关键字参数

        Returns:
            float: 配置项的值
        """
        with self._lock:
            return super().getfloat(section, option, *args, **kwargs)

    def getboolean(self, section, option, *args, **kwargs):
        """
        重写getboolean方法，使用锁保证线程安全

        Args:
            section (str): 配置项所属的section
            option (str): 配置项名称
            *args: 可变参数
            **kwargs: 关键字参数

        Returns:
            bool: 配置项的值
        """
        with self._lock:
            return super().getboolean(section, option, *args, **kwargs)

    def getList(self, section, option):
        """
        获取配置项的值，并将其转换为列表

        Args:
            section (str): 配置项所属的section
            option (str): 配置项名称

        Returns:
            list: 配置项的值
        """
        value = self.get(section, option)
        Match = re.match(r"\[(.*)?\]$", value.strip())
        if Match is None:
            return None
        valueList = [item.strip() for item in Match.group(1).split(",") if item.strip()]

        def convert(value):
            stripped = value.strip()
            # 检查是否为字符串（带引号）
            if stripped.startswith("'") and stripped.endswith("'"):
                return stripped.strip("'")
            elif stripped.startswith('"') and stripped.endswith('"'):
                return stripped.strip('"')

            # 数字转换（优先检查浮点数格式）
            try:
                if "." in stripped or "e" in stripped.lower():
                    return float(stripped)
                else:
                    return int(stripped)
            except ValueError:
                # 如果都不是，则作为普通字符串返回
                return stripped

        return [convert(i) for i in valueList]

    def getstring(self, section, option):
        """
        获取配置项的值，并将其转换为字符串

        Args:
            section (str): 配置项所属的section
            option (str): 配置项名称

        Returns:
            str: 配置项的值
        """
        value = self.get(section, option).strip()
        if value.startswith("'") and value.endswith("'"):
            return value.strip("'")
        elif value.startswith('"') and value.endswith('"'):
            return value.strip('"')
        else:
            return value

    def section_to_dict(self, section) -> dict:
        if section not in self.sections():
            return {}
        option_items = (
            f'"{option}": {self.get(section, option)}'
            for option in self.options(section)
        )
        json_str = "{" + ", ".join(option_items) + "}"
        return json.loads(json_str)

    def section_items(self, section):
        return self.section_to_dict(section).items()

    def set(self, section, option, value=None):
        """
        重写set方法，使用锁保证线程安全

        Args:
            section (str): 配置项所属的section
            option (str): 配置项名称
            value (str, optional): 配置项的值。默认为None
        """
        with self._lock:
            if value is None:
                value = self.get(section, option)
            elif isinstance(value, bool):
                value = str(value).lower()
            elif isinstance(value, float):
                value = str(value)
            elif isinstance(value, int):
                value = str(value)
            elif isinstance(value, list):
                value = str(value).replace("'", '"')
            return super().set(section, option, value)

    def save(self, filePath=None):
        """
        保存配置文件

        Args:
            filePath (str): 配置文件路径
        """
        with self._lock:
            if filePath is None and hasattr(self, "_filePath"):
                filePath = self._filePath
            elif filePath is not None:
                self._filePath = filePath
            elif not hasattr(self, "_filePath"):
                raise ValueError("No file path specified for saving")
            with open(filePath, "w", encoding=self._get_encoding()) as f:
                self.write(f)

    def _get_encoding(self):
        """
        获取文件编码，默认为utf-8

        Returns:
            str: 文件编码
        """
        return getattr(self, "_encoding", "utf-8")

    def read(self, filenames, encoding=None):
        """
        重写read方法，记录文件路径和编码

        Args:
            filenames (str|list): 文件名或文件名列表
            encoding (str|None): 文件编码
        """
        if isinstance(filenames, str):
            self._filePath = filenames
        if encoding is not None:
            self._encoding = encoding
        if not os.path.exists(filenames):
            with open(filenames, "w", encoding=self._encoding) as f:
                f.write("")
        return super().read(filenames, self._encoding)


class ConfigParserPools:
    """
    MyConfigParser对象管理池，用于多线程并发访问
    """

    _LOCK = threading.RLock()
    _pool_size = 10
    _pool = collections.OrderedDict()

    @classmethod
    def get(cls, filePath) -> _MyConfigparser:
        """
        从对象池中获取MyConfigParser对象, 如果没有则创建一个。
        对象池的数量不超出self._pool_size, 超出则删除最老的对象

        Args:
            filePath (str): 配置文件路径

        Returns:
            MyConfigParser: MyConfigParser对象
        """
        with cls._LOCK:
            filePath_ABS = os.path.abspath(filePath)
            if filePath_ABS in cls._pool:
                # 对象已存在, 返回，并把这一组键值对移到末尾
                cls._pool.move_to_end(filePath_ABS)
                return cls._pool[filePath_ABS]

            if len(cls._pool) == cls._pool_size:
                # 对象池已满, 删除第一个对象
                cls._pool.popitem(last=False)
            cls._pool[filePath_ABS] = _MyConfigparser()
            cls._pool[filePath_ABS].read(filePath_ABS)
            return cls._pool[filePath_ABS]

    @classmethod
    def remove(cls, filePath):
        """
        主动删除对象池中的对象，建议在使用完毕后调用
        Args:
            filePath (str): 配置文件路径
        """
        with cls._LOCK:
            filePath_ABS = os.path.abspath(filePath)
            if filePath_ABS in cls._pool:
                cls._pool.pop(filePath_ABS)

    @classmethod
    def setSize(cls, size):
        """
        设置对象池大小
        Args:
            size (int): 对象池大小
        """
        cls._pool_size = size
