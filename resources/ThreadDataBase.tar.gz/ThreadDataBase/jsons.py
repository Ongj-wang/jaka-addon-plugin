# -*- coding: utf-8 -*-
import collections
import json
import os
import threading


class _MyJSON:
    def __init__(self, filePath):
        self._filePath = filePath
        self._lock = threading.RLock()
        if not os.path.exists(filePath):
            self.write({})

    def read(self):
        with self._lock:
            with open(self._filePath, "r", encoding="utf-8") as f:
                return json.load(f)

    def write(self, data):
        with self._lock:
            with open(self._filePath, "w", encoding="utf-8") as f:
                json.dump(data, f, ensure_ascii=False, indent=4)


class JSONPools:
    """
    JSON文件的句柄多线程管理
    """

    _LOCK = threading.RLock()
    _pool_size = 10
    _pool = collections.OrderedDict()

    @classmethod
    def get(cls, filePath) -> _MyJSON:
        """
        从对象池中获取MyConfigParser对象, 如果没有则创建一个。
        对象池的数量不超出self._pool_size, 超出则删除最老的对象

        Args:
            filePath (str): 配置文件路径

        Returns:
            MyConfigParser: MyConfigParser对象
        """
        with cls._LOCK:
            filePath_ABS = os.path.abspath(filePath)
            if filePath_ABS in cls._pool:
                cls._pool.move_to_end(filePath_ABS)
                return cls._pool[filePath_ABS]
            if len(cls._pool) >= cls._pool_size:
                cls._pool.popitem(last=False)
            cls._pool[filePath_ABS] = _MyJSON(filePath_ABS)
            return cls._pool[filePath_ABS]

    @classmethod
    def load(cls, filePath) -> dict:
        """
        直接将json文件载入字典返回
        """
        with cls._LOCK:
            return cls.get(filePath).read()

    @classmethod
    def remove(cls, filePath):
        """
        主动删除对象池中的对象，建议在使用完毕后调用
        Args:
            filePath (str): 配置文件路径
        """
        with cls._LOCK:
            filePath_ABS = os.path.abspath(filePath)
            if filePath_ABS in cls._pool:
                cls._pool.pop(filePath_ABS)

    @classmethod
    def setSize(cls, size):
        """
        设置对象池大小
        Args:
            size (int): 对象池大小
        """
        with cls._LOCK:
            cls._pool_size = size
