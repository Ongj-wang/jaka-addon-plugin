# -*- coding: utf-8 -*-
import collections
import json
import os
import sqlite3
import threading
from typing import Any, Dict


class ParaTypes:
    INT = "INTEGER"
    TEXT = "TEXT"
    FLOAT = "REAL"
    BOOL = "BOOL"
    LIST = "TEXT"


class _LazySQL:
    def __init__(self, db_path: str):
        self.db_path = db_path
        self._lock = threading.Lock()  # 用于保护写操作和结构变更
        self._column_types = {}  # 缓存表的列类型信息

    def _get_column_types(self, conn, table_name):
        """获取并缓存表的列类型信息"""
        if table_name not in self._column_types:
            cursor = conn.execute(f"PRAGMA table_info({table_name})")
            columns_info = cursor.fetchall()
            self._column_types[table_name] = {
                col["name"]: col["type"]
                for col in columns_info  # 列名: 类型
            }
        return self._column_types[table_name]

    def _get_connection(self):
        """获取新连接（线程安全）"""
        conn = sqlite3.connect(self.db_path, check_same_thread=False)
        conn.row_factory = self._dict_factory
        return conn

    def _dict_factory(self, cursor, row):
        fields = [column[0] for column in cursor.description]
        ret = {
            key: self._deserialize_value(value) if key != "id" else value
            for key, value in zip(fields, row)
        }
        return ret

    def _serialize_value(self, value):
        if isinstance(value, (list, tuple)):
            if all(isinstance(x, (int, float)) for x in value):
                return json.dumps(value)
            else:
                raise ValueError("Only numeric arrays (int/float) are supported.")
        elif isinstance(value, bool):
            return int(value)
        else:
            return value

    def _deserialize_value(self, value):
        if isinstance(value, str):
            try:
                parsed = json.loads(value)
                if isinstance(parsed, list) and all(
                    isinstance(x, (int, float)) for x in parsed
                ):
                    return parsed
            except (json.JSONDecodeError, TypeError):
                pass
        return value

    def _find_primary_key(self, conn, table_name: str) -> str:
        """获取表的主键字段名"""
        cursor = conn.execute(f"PRAGMA table_info({table_name})")
        columns_info = cursor.fetchall()
        for col in columns_info:
            if col["pk"] == 1:  # 第6列(pk)为1表示是主键
                primary_key = col["name"]
                break
        return primary_key

    def _change_column_type(self, conn, table_name, row):
        column_types = self._get_column_types(conn, table_name)
        return {
            col: bool(row[col]) if typ.lower() == "bool" else row[col]
            for col, typ in column_types.items()
        }

    # ====== 表结构操作（需加锁） ======
    def create_table(self, table_name: str, primary_key: str, schema: Dict[str, str]):
        with self._lock:
            conn = self._get_connection()
            try:
                columns = ", ".join(
                    [
                        f"{col} {typ}"
                        for col, typ in schema.items()
                        if col != primary_key
                    ]
                )
                sql = f"CREATE TABLE IF NOT EXISTS {table_name} ({primary_key} INTEGER PRIMARY KEY, {columns})"
                conn.execute(sql)
                conn.commit()
            finally:
                conn.close()

    def drop_table(self, table_name: str):
        with self._lock:
            conn = self._get_connection()
            try:
                conn.execute(f"DROP TABLE IF EXISTS {table_name}")
                conn.commit()
            finally:
                conn.close()

    def copy_table(self, src_table: str, dst_table: str):
        with self._lock:
            conn = self._get_connection()
            try:
                cursor = conn.cursor()
                cursor.execute(
                    "SELECT sql FROM sqlite_master WHERE type='table' AND name=?",
                    (src_table,),
                )
                result = cursor.fetchone()
                if not result:
                    raise ValueError(f"Table {src_table} does not exist.")
                create_sql = (
                    result[0]
                    .replace(f'"{src_table}"', f'"{dst_table}"')
                    .replace(f"'{src_table}'", f"'{dst_table}")
                    .replace(f" {src_table} ", f" {dst_table} ")
                    .replace(f"({src_table})", f"({dst_table})")
                )
                # 更安全的方式：直接替换表名（注意引号）
                create_sql = result[0]
                if create_sql:
                    create_sql = create_sql.replace(
                        f"CREATE TABLE {src_table}", f"CREATE TABLE {dst_table}", 1
                    )
                    conn.execute(create_sql)
                    conn.execute(f"INSERT INTO {dst_table} SELECT * FROM {src_table}")
                    conn.commit()
            finally:
                conn.close()

    def table_exists(self, table_name: str) -> bool:
        """
        检查表是否存在

        :param table_name: 表名
        :return: 如果表存在返回True，否则返回False
        """
        conn = self._get_connection()
        try:
            cursor = conn.execute(
                "SELECT name FROM sqlite_master WHERE type='table' AND name=?",
                (table_name,),
            )
            return cursor.fetchone() is not None
        finally:
            conn.close()

    # ====== 数据操作（读可并发，写加锁） ======
    def insert(self, table_name: str, data: Dict[str, Any]):
        with self._lock:
            conn = self._get_connection()
            try:
                keys = list(data.keys())
                values = [self._serialize_value(data[k]) for k in keys]
                placeholders = ", ".join(["?" for _ in keys])
                columns = ", ".join(keys)
                sql = f"INSERT INTO {table_name} ({columns}) VALUES ({placeholders})"
                conn.execute(sql, values)
                conn.commit()
            finally:
                conn.close()

    def update(self, table_name: str, data: Dict[str, Any], upsert: bool = True):
        """
        插入或更新一行数据（upsert）

        :param table_name: 表名
        :param data: 数据字典。若包含 'id' 且记录存在，则更新；否则插入。
        :param upsert: 若为 False 且 id 不存在，则不插入，返回 None。
        :return: 操作后记录的 id（int），若未操作则返回 None
        """
        if not data:
            raise ValueError("Data dictionary cannot be empty.")

        with self._lock:
            conn = self._get_connection()
            try:
                # 获取表的列信息
                column_types = self._get_column_types(conn, table_name)
                primary_key = self._find_primary_key(conn, table_name)

                # 过滤掉表中不存在的列
                filtered_data = {k: v for k, v in data.items() if k in column_types}

                record_id = filtered_data.get(primary_key)
                if record_id is not None:
                    # 尝试查询是否存在
                    cur = conn.execute(
                        f"SELECT 1 FROM {table_name} WHERE {primary_key} = ?",
                        (record_id,),
                    )
                    exists = cur.fetchone() is not None
                else:
                    exists = False

                if exists:
                    # 执行更新（排除 id 字段）
                    update_data = {
                        k: v for k, v in filtered_data.items() if k != primary_key
                    }
                    if not update_data:
                        return record_id
                    set_clause = ", ".join([f"{k} = ?" for k in update_data.keys()])
                    values = [
                        self._serialize_value(v) for v in update_data.values()
                    ] + [record_id]
                    sql = (
                        f"UPDATE {table_name} SET {set_clause} WHERE {primary_key} = ?"
                    )
                    conn.execute(sql, values)
                    conn.commit()
                    return record_id
                else:
                    if not upsert:
                        return None
                    # 执行插入
                    keys = list(filtered_data.keys())
                    values = [self._serialize_value(filtered_data[k]) for k in keys]
                    placeholders = ", ".join(["?" for _ in keys])
                    columns = ", ".join(keys)
                    sql = (
                        f"INSERT INTO {table_name} ({columns}) VALUES ({placeholders})"
                    )
                    cur = conn.execute(sql, values)
                    new_id = cur.lastrowid
                    conn.commit()
                    return new_id
            finally:
                conn.close()

    def delete_row(self, table_name: str, row_id: int):
        with self._lock:
            conn = self._get_connection()
            try:
                primary_key = self._find_primary_key(conn, table_name)
                sql = f"DELETE FROM {table_name} WHERE {primary_key} = ?"
                conn.execute(sql, (row_id,))
                conn.commit()
            finally:
                conn.close()

    # def select(
    #     self, table_name: str, condition: str = "1=1", params: tuple = ()
    # ) -> List[Dict[str, Any]]:
    #     # 读操作无需加锁（SQLite 支持多读），但仍用独立连接
    #     conn = self._get_connection()
    #     try:
    #         sql = f"SELECT * FROM {table_name} WHERE {condition}"
    #         cursor = conn.execute(sql, params)
    #         return cursor.fetchall()
    #     finally:
    #         conn.close()

    def count_rows(self, table_name: str) -> int:
        conn = self._get_connection()
        try:
            cursor = conn.execute(f"SELECT COUNT(*) FROM {table_name}")
            return cursor.fetchone()[0]
        finally:
            conn.close()

    def check_row(self, table_name: str, row_id: int):
        """
        通过主键 id 获取单行数据

        :param table_name: 表名
        :param row_id: 主键 id（整数）
        :return: 字典形式的行数据，若不存在则返回 None
        """
        if not isinstance(row_id, int) or row_id <= 0:
            raise ValueError("row_id must be a positive integer.")

        conn = self._get_connection()
        # 获取表格的主键列名
        try:
            primary_key = self._find_primary_key(conn, table_name)
            cursor = conn.execute(
                f"SELECT * FROM {table_name} WHERE {primary_key} = ?", (row_id,)
            )
            row = cursor.fetchone()
            return self._change_column_type(
                conn, table_name, row
            )  # _dict_factory 已确保返回 dict 或 None
        finally:
            conn.close()

    def check_all(self, table_name: str):
        """
        获取表中所有行数据
        :param table_name: 表名
        :return: 所有行数据
        """
        conn = self._get_connection()
        try:
            cursor = conn.execute(f"SELECT * FROM {table_name}")
            rows = cursor.fetchall()
            return [self._change_column_type(conn, table_name, row) for row in rows]
        finally:
            conn.close()

    def close(self):
        # 无持久连接，无需 close
        pass


class SQLitePools:
    """
    SQLite文件的句柄多线程管理
    """

    _LOCK = threading.RLock()
    _pool = collections.OrderedDict()
    _pool_size = 10

    @classmethod
    def get(cls, filePath) -> _LazySQL:
        with cls._LOCK:
            filePath_ABS = os.path.abspath(filePath)
            if filePath_ABS in cls._pool:
                # 句柄已存在, 移到末尾
                cls._pool.move_to_end(filePath_ABS)
                return cls._pool[filePath_ABS]

            if len(cls._pool) == cls._pool_size:
                # 句柄已满, 删除第一个句柄
                cls._pool.popitem(last=False)
            cls._pool[filePath_ABS] = _LazySQL(filePath_ABS)
            return cls._pool[filePath_ABS]

    @classmethod
    def remove(cls, filePath):
        with cls._LOCK:
            filePath_ABS = os.path.abspath(filePath)
            if filePath_ABS in cls._pool:
                cls._pool.pop(filePath_ABS)
